﻿using System;
using System.Collections.Generic;

namespace ListExtensionsForOutput
{
    public class Product
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public int? CategoryID { get; set; }
        public Decimal? UnitPrice { get; set; }                
        public bool OutOfStock { get; set; }
     }

    public class Category
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }     
    }

    //public class Categories : IList<Category> { }
    //public class Products : IList<Product> { }
    
    public static class DataSource 
    {
        public static IList<Category> Categories
        {
            get
            {
                List<Category> catList = new List<Category>();
                catList.Add(new Category { CategoryID = 1, CategoryName = "Product1" });
                catList.Add(new Category { CategoryID = 2, CategoryName = "Product2" });
                catList.Add(new Category { CategoryID = 3, CategoryName = "Product3" });
                return catList;
            }
        }

        public static IList<Product> Products
        {
            get
            {
                List<Product> prodList = new List<Product>();
                prodList.Add(new Product { ProductID = 1, ProductName = "TEst1", CategoryID = 1, UnitPrice = 24.5m });
                prodList.Add(new Product { ProductID = 2, ProductName = "TEst2", CategoryID = 1, UnitPrice = 30.99m });
                prodList.Add(new Product { ProductID = 3, ProductName = "TEst3", CategoryID = 1, UnitPrice = 12.4m, OutOfStock = true });
                prodList.Add(new Product { ProductID = 4, ProductName = "Product name1", CategoryID = 1, UnitPrice = 15 });
                prodList.Add(new Product { ProductID = 5, ProductName = "Product name1", CategoryID = 2, UnitPrice = 60 });
                prodList.Add(new Product { ProductID = 6, ProductName = "Product name1 Protector", CategoryID = 2, UnitPrice = 30.4m, OutOfStock = true });
                prodList.Add(new Product { ProductID = 7, ProductName = "Product name1 Set", CategoryID = 2, UnitPrice = 40.69m });
                prodList.Add(new Product { ProductID = 8, ProductName = "Product name1 Pan", CategoryID = 3, UnitPrice = 10.99m });
                prodList.Add(new Product { ProductID = 9, ProductName = "Product name1 Maker", CategoryID = 3, UnitPrice = 49.39m });
                prodList.Add(new Product { ProductID = 10, ProductName = "Product name1 Set", CategoryID = 3, UnitPrice = 70 });
                prodList.Add(new Product { ProductID = 11, ProductName = "Product name1 Cooker", CategoryID = 3, UnitPrice = 90.5m, OutOfStock = true });
                prodList.Add(new Product { ProductID = 12, ProductName = "Product name1 Pitcher", CategoryID = 3, UnitPrice = 29.99m });
                return prodList;
            }
        }
    }
}