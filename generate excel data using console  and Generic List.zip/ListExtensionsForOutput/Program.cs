﻿using System;
using System.Collections.Generic;

namespace ListExtensionsForOutput
{
    class Program
    {
        static void Main(string[] args)
        {
            //Get string result for display on Console or Debugging window
            var result = DataSource.Products.ToString<Product>(include: "ProductName,CategoryId,UnitPrice");
            Console.Write(result);
            
            //Export to CSV file
            DataSource.Products.ToCSV<Product>(exclude: "ProductId,OutOfStock", path: @"C:\Users\Suresh.Peddapatel\Desktop.csv");

            //Open Excel from file created in user temp directory without Interop
            DataSource.Products.ToExcelNoInterop<Product>(exclude: "ProductId,OutOfStock");

            //Directly open Excel
            DataSource.Products.ToExcel<Product>(exclude: "ProductId");
            
            Console.WriteLine("");
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
